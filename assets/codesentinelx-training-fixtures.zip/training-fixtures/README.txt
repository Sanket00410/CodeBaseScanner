CodeSentinelX owned training examples. Source snippets are for static scanning, not execution. Serve example-web only with --bind 127.0.0.1. No real credentials or customer data are included.
